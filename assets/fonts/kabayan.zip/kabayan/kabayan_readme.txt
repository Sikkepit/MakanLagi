Kabayan is the name driven from Funny Character in West Java (Indonesia). It is designed for cartoon and comic artwork.

Kabayan is Freeware for personal and comercial work. But a donation is much appreciated. 

kabayan by syamsul arifin is licensed under a Creative Commons Attribution-NoDerivs 3.0 Unported License.
Based on a work at sites.google.com.
Permissions beyond the scope of this license may be available at https://sites.google.com/site/fontkabayan/.


Syamsul Arifin
e-mail: relungimaji@ymail.com
site:https://sites.google.com/site/fontkabayan/
blog: www.cartoonesia.web.id



